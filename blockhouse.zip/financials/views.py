from django.shortcuts import render
import requests
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from financials.models import StockData
from datetime import datetime
import pandas as pd

API_KEY = 'HSRNNVU7KA77QYXA'  # Replace with your Alpha Vantage API key

def fetch_financial_data(request, symbol='AAPL'):
    url = f'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={API_KEY}&outputsize=full'
    response = requests.get(url)

    # Error handling for network issues
    if response.status_code != 200:
        return JsonResponse({'error': 'Failed to fetch data'}, status=500)

    data = response.json().get('Time Series (Daily)', {})

    # Loop over the data and store it in the database
    for date_str, daily_data in data.items():
        date = datetime.strptime(date_str, '%Y-%m-%d').date()

        StockData.objects.update_or_create(
            symbol=symbol,
            date=date,
            defaults={
                'open_price': daily_data['1. open'],
                'close_price': daily_data['4. close'],
                'high_price': daily_data['2. high'],
                'low_price': daily_data['3. low'],
                'volume': daily_data['5. volume'],
            }
        )

    return JsonResponse({'message': 'Successfully fetched and stored stock data'}, status=200)

def run_backtest(data, initial_investment, buy_ma, sell_ma):
    # Initialize backtest variables
    cash = initial_investment
    shares = 0
    number_of_trades = 0
    max_drawdown = 0
    peak_value = initial_investment
    total_value = initial_investment

    # Loop through the data and apply the buy/sell rules
    for i in range(sell_ma, len(data)):  # Start after we have enough data for the moving averages
        price = float(data['close_price'].iloc[i])  # Convert decimal to float
        ma_50 = data['50_MA'].iloc[i]
        ma_200 = data['200_MA'].iloc[i]

        # Check if we should buy (price below 50-day moving average and not already holding shares)
        if price < ma_50 and shares == 0:
            shares = cash // price  # Buy as many shares as we can
            cash = cash - (shares * price)
            number_of_trades += 1
            print(f"Bought {shares} shares at {price}")

        # Check if we should sell (price above 200-day moving average and holding shares)
        elif price > ma_200 and shares > 0:
            cash += shares * price  # Sell all shares
            shares = 0
            number_of_trades += 1
            print(f"Sold shares at {price}")

        # Calculate current portfolio value
        total_value = cash + (shares * price)
        peak_value = max(peak_value, total_value)
        drawdown = (peak_value - total_value) / peak_value
        max_drawdown = max(max_drawdown, drawdown)

    # Final portfolio value if holding shares at the end
    final_value = cash + (shares * float(data['close_price'].iloc[-1]))

    # Calculate return on investment
    total_return = (final_value - initial_investment) / initial_investment * 100

    # Generate a performance summary
    performance_summary = {
        'initial_investment': initial_investment,
        'final_value': final_value,
        'total_return': total_return,
        'number_of_trades': number_of_trades,
        'max_drawdown': max_drawdown * 100  # Convert to percentage
    }

    return performance_summary


def backtest_strategy(request, symbol='AAPL'):
    try:
        # Get parameters from the request
        initial_investment = float(request.GET.get('initial_investment', 10000))  # Default to 10,000
        buy_moving_average = int(request.GET.get('buy_moving_average', 50))  # Default to 50-day MA
        sell_moving_average = int(request.GET.get('sell_moving_average', 200))  # Default to 200-day MA

        # Fetch historical stock data
        stock_data = StockData.objects.filter(symbol=symbol).order_by('date')
        if not stock_data.exists():
            return JsonResponse({'error': 'No stock data available for this symbol'}, status=404)

        # Convert stock data to a DataFrame for easier manipulation
        data = pd.DataFrame(list(stock_data.values('date', 'close_price')))
        data.set_index('date', inplace=True)
        data['50_MA'] = data['close_price'].rolling(window=buy_moving_average).mean()
        data['200_MA'] = data['close_price'].rolling(window=sell_moving_average).mean()

        # Call the backtesting function (defined later)
        result = run_backtest(data, initial_investment, buy_moving_average, sell_moving_average)

        # Return the result as JSON
        return JsonResponse(result, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)